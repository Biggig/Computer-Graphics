#include <GL/glew.h>
#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

#define W 300
#define H 300
#define R 10
int ENERGY = - 300;
int DAMP = 100;
#define SLEEPTIME 0.5

#define x1old 295
#define x2old 900
#define y1old 45
#define y2old 650
#define PAI 3.1415926535


float water[2][W][H];
bool vaild[W][H];
int points[2][2];
int points2[2][2];
int t = 0, f = 1;


bool rotate_flag = 0;
bool light_flag = 0;
bool excute_flag = 1;
bool change_once = 1;
bool create_flag = 0;
int points_count = 0;

int init_x = 500;
int init_y = 100;
int init_width = 1200;
int init_height = 700;

const GLfloat factor = 0.1f;
//GLfloat num = 0.0f;

void cal();







//��ȡtga��ʽ

#pragma pack(1)//�ṹ���ֽڶ���
typedef struct
{
	GLbyte  identsize;              // Size of ID field that follows header (0)
	GLbyte  colorMapType;           // 0 = None, 1 = paletted
	GLbyte  imageType;              // 0 = none, 1 = indexed, 2 = rgb, 3 = grey, +8=rle
	unsigned short  colorMapStart;          // First colour map entry
	unsigned short  colorMapLength;         // Number of colors
	unsigned char   colorMapBits;   // bits per palette entry
	unsigned short  xstart;                 // image x origin
	unsigned short  ystart;                 // image y origin
	unsigned short  width;                  // width in pixels
	unsigned short  height;                 // height in pixels
	GLbyte  bits;                   // bits per pixel (8 16, 24, 32)
	GLbyte  descriptor;             // image descriptor
} TGAHEADER;
#pragma pack(8)


/*tgaͼƬ��ȡ*/
GLbyte *gltReadTGABits(const char *szFileName, GLint *iWidth, GLint *iHeight, GLint *iComponents, GLenum *eFormat)
{
	FILE *pFile;            // File pointer
	TGAHEADER tgaHeader;        // TGA file header
	unsigned long lImageSize;       // Size in bytes of image
	short sDepth;           // Pixel depth;
	GLbyte  *pBits = NULL;          // Pointer to bits

									// Default/Failed values
	*iWidth = 0;
	*iHeight = 0;
	*eFormat = GL_RGB;
	*iComponents = GL_RGB;

	// Attempt to open the file
	pFile = fopen(szFileName, "rb");
	if (pFile == NULL)
		return NULL;

	// Read in header (binary)
	fread(&tgaHeader, 18/* sizeof(TGAHEADER)*/, 1, pFile);

	// Do byte swap for big vs little endian
#ifdef __APPLE__
	LITTLE_ENDIAN_WORD(&tgaHeader.colorMapStart);
	LITTLE_ENDIAN_WORD(&tgaHeader.colorMapLength);
	LITTLE_ENDIAN_WORD(&tgaHeader.xstart);
	LITTLE_ENDIAN_WORD(&tgaHeader.ystart);
	LITTLE_ENDIAN_WORD(&tgaHeader.width);
	LITTLE_ENDIAN_WORD(&tgaHeader.height);
#endif

	// Get width, height, and depth of texture
	*iWidth = tgaHeader.width;
	*iHeight = tgaHeader.height;
	sDepth = tgaHeader.bits / 8;

	// Put some validity checks here. Very simply, I only understand
	// or care about 8, 24, or 32 bit targa's.
	if (tgaHeader.bits != 8 && tgaHeader.bits != 24 && tgaHeader.bits != 32)
		return NULL;

	// Calculate size of image buffer
	lImageSize = tgaHeader.width * tgaHeader.height * sDepth;

	// Allocate memory and check for success
	pBits = (GLbyte*)malloc(lImageSize * sizeof(GLbyte));
	if (pBits == NULL)
		return NULL;

	// Read in the bits
	// Check for read error. This should catch RLE or other
	// weird formats that I don't want to recognize
	if (fread(pBits, lImageSize, 1, pFile) != 1)
	{
		free(pBits);
		return NULL;
	}

	// Set OpenGL format expected
	switch (sDepth)
	{
#ifndef OPENGL_ES
	case 3:     // Most likely case
		*eFormat = GL_BGR;
		*iComponents = GL_RGB;
		break;
#endif
	case 4:
		*eFormat = GL_BGRA;
		*iComponents = GL_RGBA;
		break;
	case 1:
		*eFormat = GL_LUMINANCE;
		*iComponents = GL_LUMINANCE;
		break;
	default:        // RGB
					// If on the iPhone, TGA's are BGR, and the iPhone does not
					// support BGR without alpha, but it does support RGB,
					// so a simple swizzle of the red and blue bytes will suffice.
					// For faster iPhone loads however, save your TGA's with an Alpha!
#ifdef OPENGL_ES
		for (int i = 0; i < lImageSize; i += 3)
		{
			GLbyte temp = pBits[i];
			pBits[i] = pBits[i + 2];
			pBits[i + 2] = temp;
		}
#endif
		break;
	}

	// Done with File
	fclose(pFile);

	// Return pointer to image data
	return pBits;
}


GLuint  texName;
GLbyte *pBits;
int nWidth, nHeight, nComponents;
GLenum eFormat;










int spin_x, spin_y, spin_z; /* x-y rotation and zoom */
int h, w;                    /* height, width  of window */
int old_x, old_y, move_z;
int depth = 3;
int i = 0;


void clear_points()
{
	points_count = 0;
	points[0][0] = points[0][1] = points[1][0] = points[1][1] = 0;
	for (int i = 0; i<W; i++)
		for (int j = 0; j < H; j++)
			vaild[i][j] = 1;
}

void init()
{


	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);//�������ش洢ģʽ
										  //��ȡtgaͼ������
	pBits =
		//gltReadTGABits("/Users/app05/Desktop/opengl/stone.tga", &nWidth, &nHeight, &nComponents, &eFormat);
		gltReadTGABits("water.tga", &nWidth, &nHeight, &nComponents, &eFormat);
	if (pBits == NULL)
		printf("tga load failed");

	glGenTextures(1, &texName);//����1��δʹ�õ����������־
	glBindTexture(GL_TEXTURE_2D, texName);//������������(�洢�������ݵ�����)

										  /*�����������˷�ʽ*/
										  //ָ����������ĵ�һά����ֵ����1.0��С��0.0ʱ��Ӧ����δ�����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	//ָ����������ĵڶ�ά����ֵ����1.0��С��0.0ʱ��Ӧ����δ�����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	//����ͼ��ʹ�õ�һ��С��������״�ϣ�Ӧ����δ�����
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	/*�����������ͼ��ʹ�õ�һ������������״��ʱ�����������䣬��ѡ���������GL_NEAREST��GL_LINEAR��ǰ�߱�ʾ��ʹ��������������ӽ���һ�����ص���ɫ��Ϊ��Ҫ���Ƶ�������ɫ�������߱�ʾ��ʹ��������������ӽ������ɸ���ɫ��ͨ����Ȩƽ���㷨�õ���Ҫ���Ƶ�������ɫ",����Ч��Ҫ��ǰ�ߺá�*/
	glTexParameteri(GL_TEXTURE_2D,
		GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	//ָ����ά����
	glTexImage2D(GL_TEXTURE_2D, 0, nComponents, nWidth, nHeight, 0, eFormat, GL_UNSIGNED_BYTE, pBits);

	free(pBits);








	/*GLfloat ambient[] = { 2.5,1.5,0.5,1.0 };
	GLfloat diffuse[] = { 2.0,1.0,1.0 };
	GLfloat specular[] = { 1.0,1.5,0.1 };
	GLfloat position[] = { 1.0,0.0,2.0,1.0 };
	glLightfv(GL_LIGHT0, GL_POSITION, position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, specular);*/

	//glEnable(GL_LIGHTING);
	//glEnable(GL_LIGHT0);
	for(int i=0; i<W; i++)
		for (int j = 0; j < H; j++)
			water[0][j][i] = water[1][j][i] = 0;
	clear_points();
}

void myDisplay(void) {
	if (excute_flag == 0 && change_once == 0)
		return;
	if (excute_flag == 0 && change_once == 1)
		change_once = 0;




	glEnable(GL_TEXTURE_2D);//�����ά������ͼ
							//����������ͼ��ʽ(ֱ�Ӹ���ԭ����ɫ����ԭ����ɫ���)
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);//ֱ��ʹ����������ģʽ

	glBindTexture(GL_TEXTURE_2D, texName);//ָ����ǰʹ�õ�����(��һ��ʹ�ú͵ڶ���ʹ�ú��岻ͬ)

										  //Ϊÿ������ָ���������꣬����ָ������һ��glNormal()








	//GLfloat x;
	//set the backgroud color
	glClearColor(0, 0, 0, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glPushMatrix();
	glTranslatef(0, 0, spin_z - 300);
	glRotatef(spin_x, 0, 1, 0);
	glRotatef(spin_y, 1, 0, 0);

	glBegin(GL_POINTS);
	//set the color of the line
	glColor3f(1.0f, 1.0f, 1.0f);
	//draw the points

	cal();

	glBegin(GL_POINTS);
	for (int i = 0; i < W; i++)
	{
		//glBegin(GL_LINES);
		for (int j = 0; j < H; j++)
		{
			if (vaild[j][i] == 0)
				continue;
			//old[i][j] = now[i][j];
			//if (water[t][j][i] - 0 > 0.001)
			glColor3f(0.0f, 0.0f, 1.0f);
			//else
			//	glColor3f(1.0f, 1.0f, 1.0f);
			//glVertex3f((double)i / 100 - 0.5, water[t][j][i], (double)j / 100 - 0.5);
			//float xxx = (double)j / W;
			//float yyy = (double)i / H;
			//cout << xxx << yyy << endl;
			if (water[t][j][i] - 0 > 0.001)
				glColor3f(0.0f, 0.0f, 1.0f);
			else
				glTexCoord3f((double)j/W, (double)i / H , water[t][j][i]);
			glVertex3f(j - W / 2, i - H / 2, water[t][j][i]);
			//cout << water[t][j][i] << " ";
		}
		//glEnd();
		//cout << endl; 
	}
	glEnd();

	int tmp = t; t = f; f = tmp;

	//glFlush();
	glPopMatrix();
	glutSwapBuffers();
	Sleep(SLEEPTIME);
}

void cal()
{
	if (!excute_flag)
		return;
	int x, y;
	float n;
	/*for (y = W/4; y < W *3/4; y++)
		for (x = H/4; x < H*3/4; x++)
			vaild[x][y] = 0;*/
	for (y = 1; y < W - 1; y++) {
		for (x = 1; x < H - 1; x++) 
		{
			if (vaild[x][y] == 0)
			{
				water[f][x][y] = 0;
				water[t][x][y] = 0;
				continue;
			}
			n = (water[t][x - 1][y] +
				water[t][x + 1][y] +
				water[t][x][y - 1] +
				water[t][x][y + 1]
				) / 2;
			n -= water[f][x][y];
			n = n - (n / DAMP);
			water[f][x][y] = n;
		}
	}

	y = 0;
	for (x = 1; x < W - 1; x++) {
		n = (water[t][x - 1][y] +
			water[t][x + 1][y] +
			water[t][x][y + 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}


	x = 0;
	for (y = 1; y < H - 1; y++) {
		n = (water[t][x + 1][y] +
			water[t][x][y - 1] +
			water[t][x][y + 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}

	x = W - 1;
	for (y = 1; y < H - 1; y++) {
		n = (water[t][x - 1][y] +
			water[t][x][y - 1] +
			water[t][x][y + 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}
	y = H - 1;
	for (x = 1; x < W - 1; x++) {
		n = (water[t][x - 1][y] +
			water[t][x + 1][y] +
			water[t][x][y - 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}
}

//int num = 0;
//int delay = 70;

void spinCube() {
	/*if (!(++num %delay))   //�������ˮ��
	{
		water[f][rand() % W][rand() % H] = -rand() % 200;
		delay = rand() % 100 + 50;
	}*/


	//num = num + 0.07;
	//cal();
	glutPostRedisplay();
	//system("pause");
}

void myReshape(GLsizei w, GLsizei h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat)w / (GLfloat)h, 1.0, 2000.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void click(int button, int state, int x, int y)
{
	if (rotate_flag)
	{
		switch (button) {
			case 0:
				old_x = x - spin_x;
				old_y = y - spin_y;
				break;
			case 2:
				old_y = y - spin_z;
				move_z = (move_z ? 0 : 1);
			}
		glutPostRedisplay();
	}

	switch (button) {
	case 0:
		old_x = x - spin_x;
		old_y = y - spin_y;
		break;
	case 2:
		old_y = y - spin_z;
		move_z = (move_z ? 0 : 1);
	}
	glutPostRedisplay();


	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//cout << x << " " << y << endl;
		if (create_flag)
		{
			if (x1old <= x && x <= x2old && y1old <= y && y <= y2old)
			{
				int xx = (double)(x - x1old) / (x2old - x1old) * W;
				int yy = (double)(y - y1old) / (y2old - y1old) * H;
				yy = H - yy;
				if (points_count == 0)
				{
					points[0][0] = xx;
					points[0][1] = yy;
					//cout << xx << " " << yy << endl;
					//points2[0][0] = x;
					//points2[0][1] = y;
					points_count=1;
					
				}
				else if (points_count == 1)
				{
					points[1][0] = xx;
					points[1][1] = yy;
					//cout << xx << " " << yy << endl;
					//points2[1][0] = x;
					//points2[1][1] = y;
					points_count = 0;
					int x1, x2, y1, y2;
					x1 = min(points[0][0], points[1][0]);
					x2 = max(points[0][0], points[1][0]);
					y1 = min(points[0][1], points[1][1]);
					y2 = max(points[0][1], points[1][1]);
					for (int i = x1; i <= x2; i++)
						for (int j = y1; j <= y2; j++)
						{
							vaild[i][j] = 0;
						}
					//cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl;
					//glPointSize(20); 
					glColor3f(1.0, 0.0, 0.0);
					glBegin(GL_LINES);
						glVertex3f(points[0][0], points[0][1], 0);
						glVertex3f(points[1][0], points[0][1], 0);
						glVertex3f(points[1][1], points[1][0], 0);
						glVertex3f(points[0][0], points[1][0], 0);
						glVertex3f(points[0][0], points[0][1], 0);
					glEnd();
					//glPointSize(1);

				}
			}
			return;
		}



		if (x1old <= x && x <= x2old && y1old <= y && y <= y2old)
		{
			int xx = (double)(x - x1old) / (x2old - x1old) * W;
			int yy = (double)(y - y1old) / (y2old - y1old) * H;
			yy = H - yy;
			water[f][xx][yy] = ENERGY;
		}
	}
}

void keyboard(unsigned char key, int x, int y)
{

	switch (key) {
	case 'l':
		if (light_flag)
		{

			glDisable(GL_LIGHTING);
			glDisable(GL_LIGHT0);
			light_flag = 0;
		}
		else
		{
			glEnable(GL_LIGHTING);
			glEnable(GL_LIGHT0);
			light_flag = 1;
		}
		break;
	case 'r':
		if (rotate_flag)
			rotate_flag = 0;
		else
			rotate_flag = 1;
		break;
	case 27 :  //esc
		exit(0);
		break;
	case '1':
		glutPositionWindow(init_x, init_y);
		glutReshapeWindow(init_width, init_height);
		spin_x = spin_y = spin_z = 0;
		break;
	case '2':
		glutPositionWindow(init_x, init_y);
		glutReshapeWindow(init_width, init_height);
		spin_y = 90;
		spin_x = spin_z = 0;
		break;
	case 'w':
		ENERGY += 10;
		cout << ENERGY << endl;
		break;
	case 's':
		ENERGY -= 10;
		cout << ENERGY << endl;
		break;
	case 'd':
		DAMP += 10;
		cout << DAMP  <<endl;
		break;
	case 'a':
		DAMP -= 10;
		if (DAMP == 0)
			DAMP = 10;
		cout << DAMP << endl;
		break;
	case 'c':   //creative mode
		if (create_flag==0)
		{
			cout << "Creative mode on" << endl;
			create_flag = 1;
		}	
		else
		{
			create_flag = 0;
			//clear_points();
			cout << "Creative mode off" << endl;
		}
		break;
	case 'v':
		create_flag = 0;
		clear_points();
		cout << "Clear" << endl;
		break;
	case 'p':
		if (excute_flag)
			excute_flag = 0;
		else
			excute_flag = 1;
		break;
	case ' ':
		water[f][H / 2][W / 2] = -1000;
		break;
	}
}

void motion(int x, int y) {
	if (rotate_flag)
	{
		if (!move_z) {
			spin_x = x - old_x;
			spin_y = y - old_y;
		}
		else {
			spin_z = y - old_y;
		}
		change_once = 1;
		glutPostRedisplay();
	}

	if (create_flag)
		return;

	if (x1old <= x && x <= x2old && y1old <= y && y <= y2old)
	{
		int xx = (double)(x - x1old) / (x2old - x1old) * W;
		int yy = (double)(y - y1old) / (y2old - y1old) * H;
		yy = H - yy;
		water[f][xx][yy] = ENERGY;
	}
}


int main(int argc, char *argv[]) {
	// init
	cout << "1������ͼ" << endl;
	cout << "2������ͼ" << endl;
	cout << "l����/�رչ���(������)" << endl;
	cout << "r����/�ر���תģʽ" << endl;
	cout << "space������������ˮ��" << endl;
	cout << "w: ˮ���ĳ�ʼ����+10(��ʼΪ-300,����ֵԽ������Խ��)" << endl;
	cout << "s: ˮ���ĳ�ʼ����-10" << endl;
	cout << "d: ˮ��������+10(��ʼΪ100,��ֵԽ�����ԽС)" << endl;
	cout << "a: ˮ��������-10" << endl;
	cout << "c: ��/�رս����ϰ���ģʽ" << endl;
	cout << "v: ����ϰ���" << endl;
	cout << "p: ��ͣ" << endl;
	cout << "esc: �˳�" << endl;
	glutInit(&argc, argv);
	//set mode
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	//set the position
	glutInitWindowPosition(init_x, init_y);
	//set the width and weigth
	glutInitWindowSize(init_width, init_height);
	glutCreateWindow("Ripple Simulation");
	init();
	glutReshapeFunc(myReshape);
	glutDisplayFunc(&myDisplay);
	//to set the action
	glutMouseFunc(&click);
	glutMotionFunc(motion);
	glutIdleFunc(spinCube);
	glutKeyboardFunc(keyboard);
	//loop
	glutMainLoop();
	return 0;
}