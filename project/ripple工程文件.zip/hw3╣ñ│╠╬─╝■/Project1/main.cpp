#include <GL/glut.h>
#include <math.h>
#include <iostream>
#include <Windows.h>
using namespace std;

#define W 300
#define H 300
#define R 10
int ENERGY = - 300;
int DAMP = 100;
#define SLEEPTIME 0.5

#define x1old 295
#define x2old 900
#define y1old 45
#define y2old 650
#define PAI 3.1415926535


float water[2][W][H];
int t = 0, f = 1;


bool rotate_flag = 0;
bool light_flag = 0;
bool excute_flag = 1;
bool change_once = 1;

int init_x = 500;
int init_y = 100;
int init_width = 1200;
int init_height = 700;

const GLfloat factor = 0.1f;
//GLfloat num = 0.0f;

void cal();

int spin_x, spin_y, spin_z; /* x-y rotation and zoom */
int h, w;                    /* height, width  of window */
int old_x, old_y, move_z;
int depth = 3;
int i = 0;


void init()
{
	//glEnable(GL_LIGHTING);
	//glEnable(GL_LIGHT0);
	for(int i=0; i<W; i++)
		for (int j = 0; j < H; j++)
			water[0][j][i] = water[1][j][i] = 0;
	//old[50][50] = 50;
}

void myDisplay(void) {
	if (excute_flag == 0 && change_once == 0)
		return;
	if (excute_flag == 0 && change_once == 1)
		change_once = 0;
	//GLfloat x;
	//set the backgroud color
	glClearColor(0, 0, 0, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//set the point we look it
	//glMatrixMode(GL_MODELVIEW);
	//replaces the current matrix with the identity matrix
	//glLoadIdentity();
	//gluLookAt(0, 0.5, 0.5, 0, 0, 0, 0, 0, 0.5);
	//gluLookAt(0.0, 0.5, 0.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);

	//gluLookAt(0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);


	glPushMatrix();
	glTranslatef(0, 0, spin_z - 300);
	glRotatef(spin_x, 0, 1, 0);
	glRotatef(spin_y, 1, 0, 0);

	glBegin(GL_POINTS);
	//set the color of the line
	glColor3f(1.0f, 1.0f, 1.0f);
	//draw the points


	cal();
	glBegin(GL_POINTS);
	for (int i = 0; i < W; i++)
	{
		//glBegin(GL_LINES);
		for (int j = 0; j < H; j++)
		{
			//old[i][j] = now[i][j];
			//if (water[t][j][i] - 0 > 0.001)
				glColor3f(0.0f, 0.0f, 1.0f);
			//else
			//	glColor3f(1.0f, 1.0f, 1.0f);
			//glVertex3f((double)i / 100 - 0.5, water[t][j][i], (double)j / 100 - 0.5);
			glVertex3f(j - W / 2, i - H / 2, water[t][j][i]);
			//cout << water[t][j][i] << " ";
		}
		//glEnd();
		//cout << endl; 
	}

	/*for (float i = 0.0f; i < 360.0; i += 1) {
		for (double x = 0; x < 1.0f / factor; x += 0.01f) {
			glVertex3f(x*factor*cos(i), cos(2 * x - num)*factor, x*factor*sin(i));
		}
	}*/
	glEnd();

	int tmp = t; t = f; f = tmp;

	//glFlush();
	glPopMatrix();
	glutSwapBuffers();
	Sleep(SLEEPTIME);
}

void cal()
{
	/*float c = 1.0;
	dt *= 4.9;
	for (int i = 1; i < W-1; i++)
		for (int j = 1; j < H-1; j++)
		{
			double h = 0.25*(old[i - 1][j] + old[i + 1][j] + old[i][j - 1] + old[i][j + 1]);
			h -= old[i][j];
			//h -= h / 32;
			now[i][j] = h;
			//h = 1024 - h;
			//now[i][j] += 0.5*(old[i - 1][j] + old[i + 1][j] + old[i][j - 1] + old[i][j + 1]) - old[i][j];
			//now[i][j] *= 0.99;
			//old[i][j] += now[i][j];
			//old[i][j] += now[i][j];
			//now[i][j] = 0.1*(old[i - 1][j] + old[i + 1][j] + old[i][j - 1] + old[i][j + 1]+ old[i-1][j-1]+ old[i-1][j+1] + old[i+1][j-1]+ old[i+1][j+1]);
			//now[i][j] += 0.05 *(old[i - 2][j] + old[i + 2][j] + old[i][j - 2] + old[i][j + 2]);
			//now[i][j] *= DAMP;

		}
	for (int i = 0; i < W; i++)
		for (int j = 0; j < H; j++)
		{
			old[i][j] += now[i][j];
			//glVertex3f((double)i / 100, now[i][j], (double)j / 100);
		}
	//cout << "666" << endl;*/
	if (!excute_flag)
		return;


	int x, y;
	float n;
	for (y = 1; y < W - 1; y++) {
		for (x = 1; x < H - 1; x++) {
			n = (water[t][x - 1][y] +
				water[t][x + 1][y] +
				water[t][x][y - 1] +
				water[t][x][y + 1]
				) / 2;
			n -= water[f][x][y];
			n = n - (n / DAMP);
			water[f][x][y] = n;
		}
	}

	y = 0;
	for (x = 1; x < W - 1; x++) {
		n = (water[t][x - 1][y] +
			water[t][x + 1][y] +
			water[t][x][y + 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}


	x = 0;
	for (y = 1; y < H - 1; y++) {
		n = (water[t][x + 1][y] +
			water[t][x][y - 1] +
			water[t][x][y + 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}

	x = W - 1;
	for (y = 1; y < H - 1; y++) {
		n = (water[t][x - 1][y] +
			water[t][x][y - 1] +
			water[t][x][y + 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}
	y = H - 1;
	for (x = 1; x < W - 1; x++) {
		n = (water[t][x - 1][y] +
			water[t][x + 1][y] +
			water[t][x][y - 1]
			) / 2;
		n -= water[f][x][y];
		n = n - (n / DAMP);
		water[f][x][y] = n;
	}

}


//int num = 0;
//int delay = 70;

void spinCube() {
	/*if (!(++num %delay))
	{
		water[f][rand() % W][rand() % H] = -rand() % 200;
		delay = rand() % 100 + 50;
	}*/


	//num = num + 0.07;
	//cal();
	glutPostRedisplay();
	//system("pause");
}

void myReshape(GLsizei w, GLsizei h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0, (GLfloat)w / (GLfloat)h, 1.0, 2000.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	/*// if the height is large than w, we should use the glViewport to adjust it 
	if (w < h) {
		glViewport(0, 0, w, w);
	}
	else {
		glViewport(0, 0, w, h);
	}*/
}

void click(int button, int state, int x, int y)
{
	/*if (state == GLUT_DOWN)
	{
		old[50][50] = 50;
	}*/
	if (rotate_flag)
	{
		switch (button) {
			case 0:
				old_x = x - spin_x;
				old_y = y - spin_y;
				break;
			case 2:
				old_y = y - spin_z;
				move_z = (move_z ? 0 : 1);
			}


		glutPostRedisplay();
	}

	switch (button) {
	case 0:
		old_x = x - spin_x;
		old_y = y - spin_y;
		break;
	case 2:
		old_y = y - spin_z;
		move_z = (move_z ? 0 : 1);
	}


	glutPostRedisplay();



	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		//cout << x << " " << y << endl;

		if (x1old <= x && x <= x2old && y1old <= y && y <= y2old)
		{
			int xx = (double)(x - x1old) / (x2old - x1old) * W;
			int yy = (double)(y - y1old) / (y2old - y1old) * H;
			yy = H - yy;
			//cout << xx << " " << yy << endl;
			//if(0 <= xx && xx < 100 && 0 <= yy && yy<100)
			/*for (int i = - R/2; i < R/2; i++)
			{
				for (int j = - R/2; j < R/2; j++)
				{
					if (0 <= xx + i && xx + i < 100 && 0 <= yy + i && yy + i < 100)
						{
							double d = sqrt(i * i + j * j);
							water[f][xx + i][yy + i] = ENERGY * (1 - d / R);
						}
				}
			}*/
			water[f][xx][yy] = ENERGY;
		}
		//double xrotate = spin_x * PAI / 180;
		//double yrotate = (spin_y - 60) * PAI / 180;
		/*int x1now = x1old;
		int x2now = x2old;
		int y1now = y1old;
		int y2now = y2old;*/
		/*if (301 <= x && x <= 899 && 281 <= y && y <= 489)
		{
			int xx = (double)(x-300) / (900 - 300) * 100.0;
			int yy = (double)(y-280) / (490 - 280) * 100.0;
			//cout << xx << " " << yy << endl;
			//if(0 <= xx && xx < 100 && 0 <= yy && yy<100)
			/*for (int i = - R/2; i < R/2; i++)
			{
				for (int j = - R/2; j < R/2; j++)
				{
					if (0 <= xx + i && xx + i < 100 && 0 <= yy + i && yy + i < 100)
					{
						double d = sqrt(i * i + j * j);
						water[f][xx + i][yy + i] = ENERGY * (1 - d / R);
					}
				}
			}
			water[f][xx][yy] = ENERGY;
		}*/
	}
}



void keyboard(unsigned char key, int x, int y)
{

	switch (key) {
	case 'l':
		if (light_flag)
		{
			glDisable(GL_LIGHTING);
			glDisable(GL_LIGHT0);
			light_flag = 0;
		}
		else
		{
			glEnable(GL_LIGHTING);
			glEnable(GL_LIGHT0);
			light_flag = 1;
		}
		break;
	case 'r':
		if (rotate_flag)
			rotate_flag = 0;
		else
			rotate_flag = 1;
		break;
	case 27 :  //esc
		exit(0);
		break;
	case '1':
		glutPositionWindow(init_x, init_y);
		glutReshapeWindow(init_width, init_height);
		spin_x = spin_y = spin_z = 0;
		break;
	case '2':
		glutPositionWindow(init_x, init_y);
		glutReshapeWindow(init_width, init_height);
		spin_y = 90;
		spin_x = spin_z = 0;
		break;
	case 'w':
		ENERGY += 10;
		cout << ENERGY << endl;
		break;
	case 's':
		ENERGY -= 10;
		cout << ENERGY << endl;
		break;
	case 'd':
		DAMP += 10;
		cout << DAMP  <<endl;
		break;
	case 'a':
		DAMP -= 10;
		if (DAMP == -10)
			DAMP = 0;
		cout << DAMP << endl;
		break;
	case 'p':
		if (excute_flag)
			excute_flag = 0;
		else
			excute_flag = 1;
		break;
	/*case 'f':
		if (glutGet(GLUT_WINDOW_WIDTH) < glutGet(GLUT_SCREEN_WIDTH)) {
			old_x = glutGet(GLUT_WINDOW_X);
			old_y = glutGet(GLUT_WINDOW_Y);
			old_width = glutGet(GLUT_WINDOW_WIDTH);
			old_height = glutGet(GLUT_WINDOW_HEIGHT);
			glutFullScreen();
		}
		break;
	*/
	case ' ':
		water[f][H / 2][W / 2] = -1000;
		break;
	}
}

void motion(int x, int y) {
	if (rotate_flag)
	{
		if (!move_z) {
			spin_x = x - old_x;
			spin_y = y - old_y;
		}
		else {
			spin_z = y - old_y;
		}
		change_once = 1;
		glutPostRedisplay();
	}
	
}


int main(int argc, char *argv[]) {
	// init
	cout << "1������ͼ" << endl;
	cout << "2������ͼ" << endl;
	cout << "l����/�رչ���(������)" << endl;
	cout << "r����/�ر���תģʽ" << endl;
	cout << "�ո� ����������ˮ��" << endl;
	cout << "w: ˮ���ĳ�ʼ����+10(��ʼΪ-300,����ֵԽ������Խ��)" << endl;
	cout << "s: ˮ���ĳ�ʼ����-10()" << endl;
	cout << "d: ˮ��������+10(��ʼΪ100,��ֵԽ�����ԽС)" << endl;
	cout << "a: ˮ��������-10" << endl;
	cout << "p: ��ͣ" << endl;
	cout << "esc: �˳�" << endl;
	glutInit(&argc, argv);
	//set mode
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	//set the position
	glutInitWindowPosition(init_x, init_y);
	//set the width and weigth
	glutInitWindowSize(init_width, init_height);
	glutCreateWindow("Ripple Simulation");
	init();
	glutReshapeFunc(myReshape);
	glutDisplayFunc(&myDisplay);
	//to set the action
	glutMouseFunc(&click);
	glutMotionFunc(motion);
	glutIdleFunc(spinCube);
	glutKeyboardFunc(keyboard);
	//loop
	glutMainLoop();
	return 0;
}